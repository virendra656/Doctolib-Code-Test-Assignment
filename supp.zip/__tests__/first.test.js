const app = require("../app");
const db = require("../db");
const request = require("supertest");




describe("/GET student", function () {
    test('fetch all student', async () => {
        let response = await request(app).get('/student');
        expect(response.body.length).toBe(0);
    })
})


describe("/POST student", function () {
    test('create a student', async () => {
        let response = await request(app).post('/student').send({
            name: "New Student"
        });
        expect(response.body).toHaveProperty('insertId');
    })
})


describe("/PATCH student", function () {
    test('patch a student', async () => {
        response = await request(app).get('/student');
        expect(response.body.length).toBe(1);
        expect(response.body[0]).toHaveProperty('id');
        response = await request(app).patch('/student/'+response.body[0].id);
        expect(response.body).toHaveProperty('changedRows');
        expect(response.body.changedRows).toBe(1);
        
    })
})

afterAll(async () => {
    db.query('delete  FROM student where id != 0 ;', function (error, results, fields) {
        if (error) console.log(error);
    })
});
