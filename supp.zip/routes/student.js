const express = require("express");
const router = express.Router();
const db = require("../db");


router.get("/", (req, res, next) => {
    db.query('SELECT * FROM student;', async  function (error, results, fields) {
        if (error) return next(error);
        res.status(200).json(results);
    })
})

router.post("/", (req, res) => {
    const student = req.body;
    db.query('insert into student set ?', student, function (error, results, fields) {
        if (error) throw error;
        res.status(200).json(results);
    })
})

router.patch("/:id", (req, res) => {
    const student = req.body;
    db.query('update student set name = ? where id = ?', [student.name, req.params.id], function (error, results, fields) {
        if (error) throw error;
        res.status(200).json(results);
    })
})

router.delete("/:id", (req, res) => {
    db.query('delete  FROM student where id = ? ;', [req.params.id], function (error, results, fields) {
        if (error) throw error;
        res.status(200).json(results);
    })
})


module.exports = router;