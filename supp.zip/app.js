const express = require("express");
const bodyParser = require("body-parser");
const app = express();
const db = require("./db");
const student = require("./routes/student");

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: true
}))


app.use('/student', student);

app.use(function (err, req, res, next) {
    console.error(err.stack)
    res.status(500).send('Something broke!')
})




module.exports = app;